// Navigation and Routing System
class NavigationManager {
    constructor() {
        this.currentPage = 'home';
        this.currentCoin = null;
        this.pages = ['home', 'markets', 'predictions', 'coin'];
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateActiveNav();
        this.handleInitialRoute();
    }

    bindEvents() {
        // Navigation menu clicks
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.dataset.page;
                if (page) {
                    this.navigateTo(page);
                }
            });
        });

        // Back button in coin page
        const backBtn = document.getElementById('backBtn');
        if (backBtn) {
            backBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.navigateBack();
            });
        }

        // Handle browser back/forward
        window.addEventListener('popstate', (e) => {
            this.handlePopState(e.state);
        });

        // Crypto card clicks (delegated event handling)
        document.addEventListener('click', (e) => {
            const cryptoCard = e.target.closest('.crypto-card');
            if (cryptoCard) {
                const symbol = cryptoCard.dataset.symbol;
                if (symbol) {
                    this.navigateToCoin(symbol);
                }
            }
        });
    }

    navigateTo(page) {
        if (!this.pages.includes(page)) {
            console.warn(`Invalid page: ${page}`);
            return;
        }

        this.currentPage = page;
        this.updateURL();
        this.showPage(page);
        this.updateActiveNav();
        this.triggerPageLoad(page);
    }

    navigateToCoin(symbol) {
        this.currentPage = 'coin';
        this.currentCoin = symbol;
        this.updateURL();
        this.showPage('coin');
        this.updateActiveNav();
        this.loadCoinData(symbol);
    }

    navigateBack() {
        const previousPage = this.getPreviousPage();
        this.navigateTo(previousPage);
    }

    showPage(page) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(p => {
            p.classList.remove('active');
        });

        // Show target page
        const targetPage = document.getElementById(`${page}Page`);
        if (targetPage) {
            targetPage.classList.add('active');
            targetPage.classList.add('fade-in');
            
            // Remove animation class after animation completes
            setTimeout(() => {
                targetPage.classList.remove('fade-in');
            }, CONFIG.UI.ANIMATION_DURATION);
        }
    }

    updateActiveNav() {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.dataset.page === this.currentPage && this.currentPage !== 'coin') {
                link.classList.add('active');
            }
        });

        // If on coin page, highlight home
        if (this.currentPage === 'coin') {
            const homeLink = document.querySelector('.nav-link[data-page="home"]');
            if (homeLink) {
                homeLink.classList.add('active');
            }
        }
    }

    updateURL() {
        let path = '/';
        
        switch (this.currentPage) {
            case 'markets':
                path = '/markets';
                break;
            case 'predictions':
                path = '/predictions';
                break;
            case 'coin':
                path = `/coin/${this.currentCoin}`;
                break;
            default:
                path = '/';
        }

        const state = {
            page: this.currentPage,
            coin: this.currentCoin
        };

        history.pushState(state, '', path);
    }

    handleInitialRoute() {
        const path = window.location.pathname;
        
        if (path === '/' || path === '/home') {
            this.navigateTo('home');
        } else if (path === '/markets') {
            this.navigateTo('markets');
        } else if (path === '/predictions') {
            this.navigateTo('predictions');
        } else if (path.startsWith('/coin/')) {
            const symbol = path.split('/coin/')[1];
            if (symbol) {
                this.navigateToCoin(symbol.toUpperCase());
            } else {
                this.navigateTo('home');
            }
        } else {
            // Unknown route, redirect to home
            this.navigateTo('home');
        }
    }

    handlePopState(state) {
        if (state) {
            this.currentPage = state.page || 'home';
            this.currentCoin = state.coin || null;
            this.showPage(this.currentPage);
            this.updateActiveNav();
            
            if (this.currentPage === 'coin' && this.currentCoin) {
                this.loadCoinData(this.currentCoin);
            } else {
                this.triggerPageLoad(this.currentPage);
            }
        } else {
            this.handleInitialRoute();
        }
    }

    getPreviousPage() {
        // Simple logic: coin page goes back to home, others stay where they are
        return this.currentPage === 'coin' ? 'home' : this.currentPage;
    }

    async triggerPageLoad(page) {
        switch (page) {
            case 'home':
                await this.loadHomePage();
                break;
            case 'markets':
                await this.loadMarketsPage();
                break;
            case 'predictions':
                await this.loadPredictionsPage();
                break;
        }
    }

    async loadHomePage() {
        try {
            // Load market overview
            const overview = await cryptoAPI.getMarketOverview();
            if (overview) {
                this.updateMarketOverview(overview);
            }

            // Load top cryptocurrencies
            const topCryptos = await cryptoAPI.getTopCryptos(20);
            if (topCryptos.length > 0) {
                this.displayCryptoGrid(topCryptos);
            }

            // Load featured chart (Bitcoin)
            await chartManager.createLineChart('featuredChart', 'BTC', '24h');

        } catch (error) {
            console.error('Error loading home page:', error);
        }
    }

    async loadMarketsPage() {
        // Markets page logic - similar to home but with more detailed view
        console.log('Loading markets page...');
    }

    async loadPredictionsPage() {
        // Predictions page logic
        console.log('Loading predictions page...');
    }

    async loadCoinData(symbol) {
        try {
            this.showLoadingOverlay();

            // Update page title and header
            document.title = `${symbol} - CryptoTracker Pro`;
            
            // Load coin data
            const coinData = await cryptoAPI.getCryptoData(symbol);
            this.updateCoinHeader(coinData);
            this.updateCoinStats(coinData);

            // Load coin chart
            await chartManager.createLineChart('coinChart', symbol, '24h');

            // Set up chart period controls
            this.setupCoinChartControls(symbol);

            // Set up prediction controls
            this.setupPredictionControls(symbol);

            this.hideLoadingOverlay();

        } catch (error) {
            console.error(`Error loading coin data for ${symbol}:`, error);
            this.showError(`Failed to load ${symbol} data`);
            this.hideLoadingOverlay();
        }
    }

    updateMarketOverview(overview) {
        const elements = {
            totalMarketCap: document.getElementById('totalMarketCap'),
            totalVolume: document.getElementById('totalVolume'),
            btcDominance: document.getElementById('btcDominance'),
            activeCryptos: document.getElementById('activeCryptos')
        };

        if (elements.totalMarketCap) {
            elements.totalMarketCap.textContent = `$${overview.totalMarketCapDisplay}`;
        }
        if (elements.totalVolume) {
            elements.totalVolume.textContent = `$${overview.totalVolumeDisplay}`;
        }
        if (elements.btcDominance) {
            elements.btcDominance.textContent = overview.btcDominanceDisplay;
        }
        if (elements.activeCryptos) {
            elements.activeCryptos.textContent = overview.activeCryptos.toLocaleString();
        }
    }

    displayCryptoGrid(cryptos) {
        const grid = document.getElementById('cryptoGrid');
        if (!grid) return;

        grid.innerHTML = cryptos.map(crypto => `
            <div class="crypto-card" data-symbol="${crypto.symbol}">
                <div class="crypto-header">
                    <div class="crypto-info">
                        <div class="crypto-logo">
                            <img src="${crypto.imageUrl}" alt="${crypto.name}" onerror="this.style.display='none'; this.parentElement.textContent='${crypto.symbol}'">
                        </div>
                        <div>
                            <h3 class="crypto-name">${crypto.name}</h3>
                            <p class="crypto-symbol">${crypto.symbol}</p>
                        </div>
                    </div>
                    <div class="crypto-rank">#${crypto.rank}</div>
                </div>
                <div class="crypto-price-section">
                    <div class="crypto-price">${crypto.priceDisplay}</div>
                    <div class="crypto-change ${crypto.change24h >= 0 ? 'positive' : 'negative'}">
                        ${crypto.change24h >= 0 ? '+' : ''}${crypto.change24h.toFixed(2)}%
                    </div>
                </div>
                <div class="crypto-stats">
                    <div class="crypto-stat">
                        <div class="crypto-stat-label">Market Cap</div>
                        <div class="crypto-stat-value">${Utils.formatLargeNumber(crypto.marketCap)}</div>
                    </div>
                    <div class="crypto-stat">
                        <div class="crypto-stat-label">Volume 24h</div>
                        <div class="crypto-stat-value">${Utils.formatLargeNumber(crypto.volume24h)}</div>
                    </div>
                </div>
                ${predictionSystem.isPredictionSupported(crypto.symbol) ? 
                    '<div class="crypto-prediction-badge">🧠 ML Predictions Available</div>' : ''
                }
            </div>
        `).join('');
    }

    updateCoinHeader(coinData) {
        const elements = {
            coinName: document.getElementById('coinName'),
            coinPrice: document.getElementById('coinPrice'),
            coinChange: document.getElementById('coinChange'),
            coinLogo: document.getElementById('coinLogo')
        };

        if (elements.coinName) {
            elements.coinName.textContent = `${coinData.name || coinData.symbol} (${coinData.symbol})`;
        }
        if (elements.coinPrice) {
            elements.coinPrice.textContent = coinData.priceDisplay;
        }
        if (elements.coinChange) {
            const changeData = Utils.formatPercentage(coinData.change24h);
            elements.coinChange.textContent = changeData.text;
            elements.coinChange.className = `coin-change ${changeData.class}`;
        }
        if (elements.coinLogo) {
            elements.coinLogo.src = Utils.getCryptoLogo(coinData.symbol, 64);
            elements.coinLogo.alt = coinData.name || coinData.symbol;
            elements.coinLogo.onerror = function() {
                this.style.display = 'none';
                this.parentElement.textContent = coinData.symbol;
            };
        }
    }

    updateCoinStats(coinData) {
        const statsMapping = {
            coinMarketCap: coinData.marketCapDisplay,
            coinVolume: coinData.volume24hDisplay,
            coinSupply: coinData.supplyDisplay || '--',
            coin24hHigh: Utils.formatCurrency(coinData.high24h),
            coin24hLow: Utils.formatCurrency(coinData.low24h),
            coinATH: '--' // Would need additional API call
        };

        Object.entries(statsMapping).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        });
    }

    setupCoinChartControls(symbol) {
        const chartControls = document.querySelectorAll('#coinPage .chart-btn');
        chartControls.forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                
                // Update active button
                chartControls.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                const period = btn.dataset.period || '24h';
                await chartManager.updateChartPeriod('coinChart', symbol, period);
            });
        });
    }

    setupPredictionControls(symbol) {
        const generateBtn = document.getElementById('generatePrediction');
        const freqSelect = document.getElementById('predictionFreq');
        const resultsDiv = document.getElementById('predictionResults');

        if (generateBtn) {
            generateBtn.addEventListener('click', async () => {
                if (!predictionSystem.isPredictionSupported(symbol)) {
                    this.showPredictionError('Prediction model not available for this cryptocurrency.');
                    return;
                }

                const frequency = freqSelect?.value || 'hourly';
                await this.generateAndDisplayPrediction(symbol, frequency, resultsDiv);
            });
        }
    }

    async generateAndDisplayPrediction(symbol, frequency, container) {
        if (!container) return;

        try {
            // Show loading state
            container.innerHTML = `
                <div class="prediction-loading">
                    <i class="fas fa-brain fa-spin"></i>
                    <p>Generating AI prediction for ${symbol}...</p>
                    <small>This may take a few moments</small>
                </div>
            `;

            const steps = frequency === 'hourly' ? 24 : 30;
            const prediction = await predictionSystem.generatePrediction(symbol, frequency, steps);
            const formatted = predictionSystem.formatPredictionResults(prediction);

            // Display results
            container.innerHTML = `
                <div class="prediction-summary">
                    <h4>Prediction Summary</h4>
                    <div class="prediction-grid">
                        <div class="prediction-item">
                            <div class="prediction-label">Next ${frequency === 'hourly' ? 'Hour' : 'Day'}</div>
                            <div class="prediction-value">${formatted.summary.nextPrice}</div>
                        </div>
                        <div class="prediction-item">
                            <div class="prediction-label">Final Price</div>
                            <div class="prediction-value">${formatted.summary.finalPrice}</div>
                        </div>
                        <div class="prediction-item">
                            <div class="prediction-label">Total Change</div>
                            <div class="prediction-value ${formatted.summary.totalChange.class}">
                                ${formatted.summary.totalChange.text}
                            </div>
                        </div>
                        <div class="prediction-item">
                            <div class="prediction-label">Confidence</div>
                            <div class="prediction-value">${formatted.summary.confidence}</div>
                        </div>
                    </div>
                    <div class="prediction-meta">
                        <p><strong>Trend:</strong> ${formatted.summary.trend}</p>
                        <p><strong>Volatility:</strong> ${formatted.summary.volatility}</p>
                    </div>
                </div>
                <div class="prediction-chart">
                    <canvas id="predictionChart"></canvas>
                </div>
            `;

            // Create prediction chart
            setTimeout(() => {
                this.createPredictionChart(prediction);
            }, 100);

        } catch (error) {
            console.error('Prediction generation failed:', error);
            this.showPredictionError(error.message);
        }
    }

    createPredictionChart(predictionData) {
        const canvas = document.getElementById('predictionChart');
        if (!canvas) return;

        // Get current historical data for comparison
        const historicalPromise = cryptoAPI.getHistoricalData(predictionData.symbol, '7d');
        
        historicalPromise.then(historicalData => {
            if (historicalData && historicalData.length > 0) {
                // Prepare prediction data for chart
                const predictionChartData = predictionData.predictions.map(p => ({
                    time: p.time,
                    predicted: p.close
                }));

                chartManager.createPredictionChart('predictionChart', historicalData, predictionChartData);
            }
        }).catch(error => {
            console.error('Error creating prediction chart:', error);
        });
    }

    showPredictionError(message) {
        const container = document.getElementById('predictionResults');
        if (container) {
            container.innerHTML = `
                <div class="prediction-empty">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>${message}</p>
                    <small>Please try again or select a different cryptocurrency.</small>
                </div>
            `;
        }
    }

    showLoadingOverlay() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('show');
        }
    }

    hideLoadingOverlay() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('show');
        }
    }

    showError(message) {
        // Simple error display - could be enhanced with a proper modal
        alert(message);
    }
}

// Initialize navigation manager
const navigationManager = new NavigationManager();

// Export for global use
window.NavigationManager = NavigationManager;
window.navigationManager = navigationManager;