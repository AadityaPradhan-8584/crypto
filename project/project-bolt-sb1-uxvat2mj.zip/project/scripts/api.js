// API Management and Data Fetching
class CryptoAPI {
    constructor() {
        this.baseUrl = CONFIG.API.BASE_URL;
        this.apiKey = CONFIG.API.CRYPTOCOMPARE_KEY;
        this.coinDeskUrl = CONFIG.API.COINDESK_URL;
        this.coinDeskKey = CONFIG.API.COINDESK_KEY;
        this.rateLimitQueue = [];
        this.requestCount = 0;
        this.lastRequest = 0;
    }

    // Rate limiting
    async rateLimit() {
        const now = Date.now();
        if (now - this.lastRequest < CONFIG.API.RATE_LIMIT) {
            await new Promise(resolve => 
                setTimeout(resolve, CONFIG.API.RATE_LIMIT - (now - this.lastRequest))
            );
        }
        this.lastRequest = Date.now();
    }

    // Generic API request with error handling
    async makeRequest(url, options = {}) {
        await this.rateLimit();
        
        try {
            const response = await fetch(url, {
                ...options,
                headers: {
                    'authorization': `Apikey ${this.apiKey}`,
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.Response === 'Error') {
                throw new Error(data.Message || 'API Error');
            }

            return data;
        } catch (error) {
            console.error('API Request failed:', error);
            throw error;
        }
    }

    // Get top cryptocurrencies
    async getTopCryptos(limit = 20, currency = 'USD') {
        const cacheKey = `top_cryptos_${limit}_${currency}`;
        const cached = CacheManager.get(cacheKey);
        if (cached) return cached;

        try {
            const url = `${this.baseUrl}/top/mktcapfull?limit=${limit}&tsym=${currency}`;
            const response = await this.makeRequest(url);
            
            if (!response.Data) {
                throw new Error('Invalid response format');
            }

            const cryptos = response.Data.map(item => {
                const raw = item.RAW?.[currency];
                const display = item.DISPLAY?.[currency];
                
                return {
                    id: item.CoinInfo.Id,
                    name: item.CoinInfo.FullName,
                    symbol: item.CoinInfo.Name,
                    rank: item.CoinInfo.SortOrder,
                    price: raw?.PRICE || 0,
                    priceDisplay: display?.PRICE || '$0.00',
                    change24h: raw?.CHANGEPCT24HOUR || 0,
                    change24hDisplay: display?.CHANGEPCT24HOUR || '0.00%',
                    marketCap: raw?.MKTCAP || 0,
                    marketCapDisplay: display?.MKTCAP || '$0',
                    volume24h: raw?.TOTALVOLUME24H || 0,
                    volume24hDisplay: display?.TOTALVOLUME24H || '$0',
                    supply: raw?.SUPPLY || 0,
                    imageUrl: `https://www.cryptocompare.com${item.CoinInfo.ImageUrl}`,
                    lastUpdate: raw?.LASTUPDATE || Date.now()
                };
            });

            CacheManager.set(cacheKey, cryptos);
            return cryptos;
        } catch (error) {
            console.error('Error fetching top cryptos:', error);
            return [];
        }
    }

    // Get specific cryptocurrency data
    async getCryptoData(symbol, currency = 'USD') {
        const cacheKey = `crypto_${symbol}_${currency}`;
        const cached = CacheManager.get(cacheKey);
        if (cached) return cached;

        try {
            const url = `${this.baseUrl}/pricemultifull?fsyms=${symbol}&tsyms=${currency}`;
            const response = await this.makeRequest(url);
            
            if (!response.RAW || !response.RAW[symbol]) {
                throw new Error('Crypto not found');
            }

            const raw = response.RAW[symbol][currency];
            const display = response.DISPLAY[symbol][currency];

            const cryptoData = {
                symbol: symbol,
                name: symbol, // Will be updated with full name if available
                price: raw.PRICE || 0,
                priceDisplay: display.PRICE || '$0.00',
                change24h: raw.CHANGEPCT24HOUR || 0,
                change24hDisplay: display.CHANGEPCT24HOUR || '0.00%',
                marketCap: raw.MKTCAP || 0,
                marketCapDisplay: display.MKTCAP || '$0',
                volume24h: raw.TOTALVOLUME24H || 0,
                volume24hDisplay: display.TOTALVOLUME24H || '$0',
                supply: raw.SUPPLY || 0,
                supplyDisplay: display.SUPPLY || '0',
                high24h: raw.HIGH24HOUR || 0,
                low24h: raw.LOW24HOUR || 0,
                open24h: raw.OPEN24HOUR || 0,
                lastUpdate: raw.LASTUPDATE || Date.now()
            };

            CacheManager.set(cacheKey, cryptoData);
            return cryptoData;
        } catch (error) {
            console.error(`Error fetching crypto data for ${symbol}:`, error);
            throw error;
        }
    }

    // Get historical data for charts
    async getHistoricalData(symbol, period = '24h', currency = 'USD') {
        const cacheKey = `historical_${symbol}_${period}_${currency}`;
        const cached = CacheManager.get(cacheKey);
        if (cached) return cached;

        try {
            let endpoint, limit, aggregate;
            
            switch (period) {
                case '1h':
                    endpoint = 'histominute';
                    limit = 60;
                    aggregate = 1;
                    break;
                case '24h':
                    endpoint = 'histohour';
                    limit = 24;
                    aggregate = 1;
                    break;
                case '7d':
                    endpoint = 'histohour';
                    limit = 168; // 24 * 7
                    aggregate = 1;
                    break;
                case '30d':
                    endpoint = 'histoday';
                    limit = 30;
                    aggregate = 1;
                    break;
                case '1y':
                    endpoint = 'histoday';
                    limit = 365;
                    aggregate = 1;
                    break;
                default:
                    endpoint = 'histohour';
                    limit = 24;
                    aggregate = 1;
            }

            const url = `${this.baseUrl}/${endpoint}?fsym=${symbol}&tsym=${currency}&limit=${limit}&aggregate=${aggregate}`;
            const response = await this.makeRequest(url);
            
            if (!response.Data) {
                throw new Error('No historical data available');
            }

            const historicalData = response.Data.map(item => ({
                time: item.time * 1000, // Convert to milliseconds
                open: item.open,
                high: item.high,
                low: item.low,
                close: item.close,
                volume: item.volumeto
            }));

            CacheManager.set(cacheKey, historicalData);
            return historicalData;
        } catch (error) {
            console.error(`Error fetching historical data for ${symbol}:`, error);
            return [];
        }
    }

    // Get market overview data
    async getMarketOverview() {
        const cacheKey = 'market_overview';
        const cached = CacheManager.get(cacheKey);
        if (cached) return cached;

        try {
            // Get top 100 cryptos to calculate market stats
            const topCryptos = await this.getTopCryptos(100);
            
            const totalMarketCap = topCryptos.reduce((sum, crypto) => sum + crypto.marketCap, 0);
            const totalVolume = topCryptos.reduce((sum, crypto) => sum + crypto.volume24h, 0);
            
            const btc = topCryptos.find(crypto => crypto.symbol === 'BTC');
            const btcDominance = btc ? (btc.marketCap / totalMarketCap) * 100 : 0;
            
            const overview = {
                totalMarketCap: totalMarketCap,
                totalMarketCapDisplay: Utils.formatLargeNumber(totalMarketCap),
                totalVolume: totalVolume,
                totalVolumeDisplay: Utils.formatLargeNumber(totalVolume),
                btcDominance: btcDominance,
                btcDominanceDisplay: `${btcDominance.toFixed(1)}%`,
                activeCryptos: topCryptos.length,
                timestamp: Date.now()
            };

            CacheManager.set(cacheKey, overview);
            return overview;
        } catch (error) {
            console.error('Error fetching market overview:', error);
            return null;
        }
    }

    // Search cryptocurrencies
    async searchCryptos(query) {
        if (!query || query.length < 2) return [];
        
        const cacheKey = `search_${query.toLowerCase()}`;
        const cached = CacheManager.get(cacheKey);
        if (cached) return cached;

        try {
            // For demo, we'll filter from top cryptos
            const topCryptos = await this.getTopCryptos(50);
            const results = topCryptos.filter(crypto => 
                crypto.name.toLowerCase().includes(query.toLowerCase()) ||
                crypto.symbol.toLowerCase().includes(query.toLowerCase())
            ).slice(0, 10);

            CacheManager.set(cacheKey, results);
            return results;
        } catch (error) {
            console.error('Error searching cryptos:', error);
            return [];
        }
    }

    // Get crypto news (mock implementation)
    async getCryptoNews(symbol, limit = 10) {
        const cacheKey = `news_${symbol}_${limit}`;
        const cached = CacheManager.get(cacheKey);
        if (cached) return cached;

        try {
            const url = `${this.baseUrl}/v2/news/?categories=${symbol}&lang=EN&sortOrder=latest`;
            const response = await this.makeRequest(url);
            
            if (!response.Data) {
                return [];
            }

            const news = response.Data.slice(0, limit).map(item => ({
                id: item.id,
                title: item.title,
                body: item.body,
                url: item.url,
                imageUrl: item.imageurl,
                publishedAt: item.published_on * 1000,
                source: item.source_info?.name || 'Unknown',
                categories: item.categories?.split('|') || []
            }));

            CacheManager.set(cacheKey, news);
            return news;
        } catch (error) {
            console.error(`Error fetching news for ${symbol}:`, error);
            return [];
        }
    }

    // Get multiple crypto prices (for real-time updates)
    async getMultiplePrices(symbols, currency = 'USD') {
        if (!Array.isArray(symbols) || symbols.length === 0) return {};

        const cacheKey = `prices_${symbols.join(',')}_${currency}`;
        const cached = CacheManager.get(cacheKey);
        if (cached) return cached;

        try {
            const symbolsStr = symbols.join(',');
            const url = `${this.baseUrl}/price?fsym=${symbolsStr}&tsyms=${currency}`;
            const response = await this.makeRequest(url);
            
            CacheManager.set(cacheKey, response, 30000); // Cache for 30 seconds
            return response;
        } catch (error) {
            console.error('Error fetching multiple prices:', error);
            return {};
        }
    }
}

// Initialize API instance
const cryptoAPI = new CryptoAPI();

// Export for global use
window.CryptoAPI = CryptoAPI;
window.cryptoAPI = cryptoAPI;