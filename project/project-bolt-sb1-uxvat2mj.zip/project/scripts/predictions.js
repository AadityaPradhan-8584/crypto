// ML Prediction System (Client-side simulation)
class PredictionSystem {
    constructor() {
        this.supportedCoins = CONFIG.CRYPTO.SUPPORTED_MODELS;
        this.predictionCache = new Map();
        this.isLoading = false;
    }

    // Mock prediction function (simulates the Python predict.py functionality)
    async generatePrediction(coinSymbol, frequency, steps = 24) {
        const cacheKey = `prediction_${coinSymbol}_${frequency}_${steps}`;
        
        // Check cache first
        if (this.predictionCache.has(cacheKey)) {
            const cached = this.predictionCache.get(cacheKey);
            if (Date.now() - cached.timestamp < 300000) { // 5 minutes cache
                return cached.data;
            }
        }

        // Validate inputs
        if (!this.supportedCoins.includes(coinSymbol.toUpperCase())) {
            throw new Error(`Prediction model not available for ${coinSymbol}`);
        }

        const limits = CONFIG.CRYPTO.PREDICTION_LIMITS[frequency];
        if (!limits || steps < limits.min || steps > limits.max) {
            throw new Error(`Invalid step count. ${frequency} predictions support ${limits?.min}-${limits?.max} steps`);
        }

        this.isLoading = true;

        try {
            // Get current market data
            const currentData = await cryptoAPI.getCryptoData(coinSymbol);
            const historicalData = await cryptoAPI.getHistoricalData(coinSymbol, '7d');
            
            if (!currentData || !historicalData || historicalData.length === 0) {
                throw new Error('Insufficient data for prediction');
            }

            // Simulate prediction generation (in real implementation, this would call your Python backend)
            const prediction = await this.simulatePrediction(currentData, historicalData, frequency, steps);
            
            // Cache the result
            this.predictionCache.set(cacheKey, {
                data: prediction,
                timestamp: Date.now()
            });

            return prediction;
        } catch (error) {
            console.error('Prediction generation failed:', error);
            throw error;
        } finally {
            this.isLoading = false;
        }
    }

    // Simulate ML prediction (replace with actual backend call)
    async simulatePrediction(currentData, historicalData, frequency, steps) {
        // Add artificial delay to simulate processing
        await new Promise(resolve => setTimeout(resolve, 2000));

        const lastPrice = currentData.price;
        const prices = historicalData.slice(-30).map(item => item.close);
        
        // Calculate some basic statistics
        const avgPrice = prices.reduce((sum, price) => sum + price, 0) / prices.length;
        const volatility = this.calculateVolatility(prices);
        const trend = this.calculateTrend(prices);
        
        // Generate predictions using a simple model with some randomness
        const predictions = [];
        let currentPrice = lastPrice;
        
        for (let i = 1; i <= steps; i++) {
            // Simulate price movement with trend and volatility
            const trendEffect = trend * 0.1;
            const volatilityEffect = (Math.random() - 0.5) * volatility * 0.05;
            const meanReversion = (avgPrice - currentPrice) * 0.02;
            
            const priceChange = trendEffect + volatilityEffect + meanReversion;
            currentPrice = Math.max(0, currentPrice * (1 + priceChange));
            
            // Generate OHLC values around the predicted close price
            const high = currentPrice * (1 + Math.random() * volatility * 0.02);
            const low = currentPrice * (1 - Math.random() * volatility * 0.02);
            const open = i === 1 ? lastPrice : predictions[i - 2]?.close || currentPrice;
            const volume = currentData.volume24h * (0.8 + Math.random() * 0.4);
            
            const timeIncrement = frequency === 'hourly' ? 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
            const predictedTime = Date.now() + (i * timeIncrement);
            
            predictions.push({
                time: predictedTime,
                step: i,
                open: Math.max(0, open),
                high: Math.max(0, Math.max(high, currentPrice, open)),
                low: Math.max(0, Math.min(low, currentPrice, open)),
                close: currentPrice,
                volume: Math.max(0, volume),
                confidence: Math.max(0.3, 1 - (i / steps) * 0.6) // Decreasing confidence over time
            });
        }

        return {
            symbol: currentData.symbol,
            frequency: frequency,
            steps: steps,
            predictions: predictions,
            metadata: {
                model_version: '1.0.0',
                confidence_avg: predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.length,
                trend_direction: trend > 0 ? 'bullish' : trend < 0 ? 'bearish' : 'neutral',
                volatility_level: volatility > 0.1 ? 'high' : volatility > 0.05 ? 'medium' : 'low',
                generated_at: Date.now(),
                based_on_data_points: historicalData.length
            }
        };
    }

    // Calculate simple volatility
    calculateVolatility(prices) {
        if (prices.length < 2) return 0;
        
        const returns = [];
        for (let i = 1; i < prices.length; i++) {
            returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
        }
        
        const avgReturn = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
        const variance = returns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / returns.length;
        
        return Math.sqrt(variance);
    }

    // Calculate simple trend
    calculateTrend(prices) {
        if (prices.length < 2) return 0;
        
        const firstHalf = prices.slice(0, Math.floor(prices.length / 2));
        const secondHalf = prices.slice(Math.floor(prices.length / 2));
        
        const firstAvg = firstHalf.reduce((sum, price) => sum + price, 0) / firstHalf.length;
        const secondAvg = secondHalf.reduce((sum, price) => sum + price, 0) / secondHalf.length;
        
        return (secondAvg - firstAvg) / firstAvg;
    }

    // Get prediction summary for specific step
    getPredictionSummary(predictionData, step) {
        if (!predictionData || !predictionData.predictions) {
            return null;
        }

        const prediction = predictionData.predictions.find(p => p.step === step);
        if (!prediction) return null;

        return {
            time: prediction.time,
            timeDisplay: new Date(prediction.time).toLocaleString(),
            price: prediction.close,
            priceDisplay: Utils.formatCurrency(prediction.close),
            change: ((prediction.close - predictionData.predictions[0].close) / predictionData.predictions[0].close) * 100,
            changeDisplay: Utils.formatPercentage(((prediction.close - predictionData.predictions[0].close) / predictionData.predictions[0].close) * 100),
            confidence: prediction.confidence,
            confidenceDisplay: `${(prediction.confidence * 100).toFixed(1)}%`,
            ohlc: {
                open: prediction.open,
                high: prediction.high,
                low: prediction.low,
                close: prediction.close,
                volume: prediction.volume
            }
        };
    }

    // Format prediction for display
    formatPredictionResults(predictionData) {
        if (!predictionData) return null;

        const { predictions, metadata } = predictionData;
        const nextPrediction = predictions[0];
        const finalPrediction = predictions[predictions.length - 1];
        
        const currentPrice = nextPrediction ? nextPrediction.close : 0;
        const finalPrice = finalPrediction ? finalPrediction.close : 0;
        const totalChange = currentPrice > 0 ? ((finalPrice - currentPrice) / currentPrice) * 100 : 0;

        return {
            summary: {
                nextPrice: nextPrediction ? Utils.formatCurrency(nextPrediction.close) : '--',
                nextChange: nextPrediction ? Utils.formatPercentage(((nextPrediction.close - currentPrice) / currentPrice) * 100) : { text: '--', class: '' },
                finalPrice: finalPrediction ? Utils.formatCurrency(finalPrediction.close) : '--',
                totalChange: Utils.formatPercentage(totalChange),
                confidence: `${(metadata.confidence_avg * 100).toFixed(1)}%`,
                trend: metadata.trend_direction,
                volatility: metadata.volatility_level
            },
            predictions: predictions.map(p => ({
                step: p.step,
                time: new Date(p.time).toLocaleString(),
                price: Utils.formatCurrency(p.close),
                change: Utils.formatPercentage(((p.close - currentPrice) / currentPrice) * 100),
                confidence: `${(p.confidence * 100).toFixed(1)}%`
            })),
            chartData: {
                labels: predictions.map(p => p.time),
                prices: predictions.map(p => p.close),
                confidence: predictions.map(p => p.confidence)
            }
        };
    }

    // Check if prediction is available for coin
    isPredictionSupported(coinSymbol) {
        return this.supportedCoins.includes(coinSymbol.toUpperCase());
    }

    // Get supported models
    getSupportedModels() {
        return [...this.supportedCoins];
    }

    // Clear prediction cache
    clearCache() {
        this.predictionCache.clear();
    }
}

// Initialize prediction system
const predictionSystem = new PredictionSystem();

// Export for global use
window.PredictionSystem = PredictionSystem;
window.predictionSystem = predictionSystem;