// Configuration and Constants
const CONFIG = {
    API: {
        COINDESK_KEY: 'da3f7a681558318ac0d2be9df5f07deae6e723c2321dc638e42a8f27b1f12ce5',
        CRYPTOCOMPARE_KEY: 'da3f7a681558318ac0d2be9df5f07deae6e723c2321dc638e42a8f27b1f12ce5',
        BASE_URL: 'https://min-api.cryptocompare.com/data',
        COINDESK_URL: 'https://data-api.coindesk.com/index/cc/v1',
        RATE_LIMIT: 1000, // ms between requests
    },
    
    CHART: {
        COLORS: {
            primary: '#3b82f6',
            success: '#22c55e',
            error: '#ef4444',
            warning: '#f59e0b',
            gradient: {
                start: '#3b82f6',
                end: '#1d4ed8'
            }
        },
        TIMEFRAMES: {
            '1h': { limit: 60, aggregate: 1 },
            '24h': { limit: 24, aggregate: 1 },
            '7d': { limit: 7, aggregate: 1 },
            '30d': { limit: 30, aggregate: 1 },
            '1y': { limit: 365, aggregate: 1 }
        }
    },
    
    CRYPTO: {
        TOP_COINS: ['BTC', 'ETH', 'XRP', 'ADA', 'BNB', 'SOL', 'DOT', 'MATIC', 'LINK', 'UNI'],
        SUPPORTED_MODELS: ['BTC', 'ETH', 'XRP', 'ADA', 'BNB', 'SOL', 'DOT', 'MATIC'],
        REFRESH_INTERVAL: 30000, // 30 seconds
        PREDICTION_LIMITS: {
            hourly: { min: 1, max: 24 },
            daily: { min: 1, max: 30 }
        }
    },
    
    UI: {
        ANIMATION_DURATION: 300,
        DEBOUNCE_DELAY: 300,
        LOADING_MIN_TIME: 1000,
        ITEMS_PER_PAGE: 20
    },
    
    STORAGE: {
        THEME_KEY: 'cryptoTracker_theme',
        FAVORITES_KEY: 'cryptoTracker_favorites',
        CACHE_DURATION: 5 * 60 * 1000, // 5 minutes
    }
};

// Utility Functions
const Utils = {
    // Format currency with proper symbols and decimals
    formatCurrency(value, currency = 'USD', decimals = 2) {
        if (value === null || value === undefined || isNaN(value)) return '--';
        
        const formatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: currency,
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        });
        
        return formatter.format(value);
    },
    
    // Format large numbers with abbreviations (K, M, B, T)
    formatLargeNumber(value, decimals = 1) {
        if (value === null || value === undefined || isNaN(value)) return '--';
        
        const abs = Math.abs(value);
        if (abs >= 1e12) return (value / 1e12).toFixed(decimals) + 'T';
        if (abs >= 1e9) return (value / 1e9).toFixed(decimals) + 'B';
        if (abs >= 1e6) return (value / 1e6).toFixed(decimals) + 'M';
        if (abs >= 1e3) return (value / 1e3).toFixed(decimals) + 'K';
        return value.toFixed(decimals);
    },
    
    // Format percentage with proper sign and color class
    formatPercentage(value, decimals = 2) {
        if (value === null || value === undefined || isNaN(value)) return { text: '--', class: '' };
        
        const formatted = `${value >= 0 ? '+' : ''}${value.toFixed(decimals)}%`;
        const className = value >= 0 ? 'positive' : 'negative';
        
        return { text: formatted, class: className };
    },
    
    // Debounce function for search and other inputs
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    
    // Generate random color for crypto logos
    generateCryptoColor(symbol) {
        const colors = [
            '#3b82f6', '#8b5cf6', '#06b6d4', '#10b981', 
            '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'
        ];
        
        let hash = 0;
        for (let i = 0; i < symbol.length; i++) {
            hash = symbol.charCodeAt(i) + ((hash << 5) - hash);
        }
        
        return colors[Math.abs(hash) % colors.length];
    },
    
    // Get time ago string
    getTimeAgo(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        if (minutes > 0) return `${minutes} min${minutes > 1 ? 's' : ''} ago`;
        return 'Just now';
    },
    
    // Validate crypto symbol
    isValidCryptoSymbol(symbol) {
        return /^[A-Z]{2,10}$/.test(symbol?.toUpperCase());
    },
    
    // Generate crypto logo URL or fallback
    getCryptoLogo(symbol, size = 64) {
        const baseUrl = 'https://cryptoicons.org/api/icon';
        return `${baseUrl}/${symbol.toLowerCase()}/${size}`;
    },
    
    // Local storage with error handling
    storage: {
        get(key, defaultValue = null) {
            try {
                const item = localStorage.getItem(key);
                return item ? JSON.parse(item) : defaultValue;
            } catch (error) {
                console.warn('Storage get error:', error);
                return defaultValue;
            }
        },
        
        set(key, value) {
            try {
                localStorage.setItem(key, JSON.stringify(value));
                return true;
            } catch (error) {
                console.warn('Storage set error:', error);
                return false;
            }
        },
        
        remove(key) {
            try {
                localStorage.removeItem(key);
                return true;
            } catch (error) {
                console.warn('Storage remove error:', error);
                return false;
            }
        }
    }
};

// Theme Management
const ThemeManager = {
    init() {
        const savedTheme = Utils.storage.get(CONFIG.STORAGE.THEME_KEY, 'light');
        this.setTheme(savedTheme);
        this.bindEvents();
    },
    
    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        Utils.storage.set(CONFIG.STORAGE.THEME_KEY, theme);
        this.updateThemeToggle(theme);
    },
    
    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        this.setTheme(newTheme);
    },
    
    updateThemeToggle(theme) {
        const toggleBtn = document.getElementById('themeToggle');
        if (toggleBtn) {
            const icon = toggleBtn.querySelector('i');
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    },
    
    bindEvents() {
        const toggleBtn = document.getElementById('themeToggle');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => this.toggleTheme());
        }
    }
};

// Cache Management
const CacheManager = {
    cache: new Map(),
    
    set(key, data, duration = CONFIG.STORAGE.CACHE_DURATION) {
        const expiry = Date.now() + duration;
        this.cache.set(key, { data, expiry });
    },
    
    get(key) {
        const cached = this.cache.get(key);
        if (!cached) return null;
        
        if (Date.now() > cached.expiry) {
            this.cache.delete(key);
            return null;
        }
        
        return cached.data;
    },
    
    clear() {
        this.cache.clear();
    },
    
    has(key) {
        const cached = this.cache.get(key);
        if (!cached) return false;
        
        if (Date.now() > cached.expiry) {
            this.cache.delete(key);
            return false;
        }
        
        return true;
    }
};

// Export for use in other modules
window.CONFIG = CONFIG;
window.Utils = Utils;
window.ThemeManager = ThemeManager;
window.CacheManager = CacheManager;