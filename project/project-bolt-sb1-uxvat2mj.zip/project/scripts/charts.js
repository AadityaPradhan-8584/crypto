// Chart Management and Visualization
class ChartManager {
    constructor() {
        this.charts = {};
        this.chartColors = CONFIG.CHART.COLORS;
        this.defaultOptions = this.getDefaultChartOptions();
    }

    // Get default chart configuration
    getDefaultChartOptions() {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        const textColor = isDark ? '#e5e5e5' : '#525252';
        const gridColor = isDark ? '#404040' : '#e5e5e5';

        return {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                intersect: false,
                mode: 'index'
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: isDark ? '#1f2937' : '#ffffff',
                    titleColor: textColor,
                    bodyColor: textColor,
                    borderColor: isDark ? '#374151' : '#d1d5db',
                    borderWidth: 1,
                    cornerRadius: 8,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return `Price: ${Utils.formatCurrency(context.parsed.y)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    display: true,
                    grid: {
                        color: gridColor,
                        drawOnChartArea: true,
                        drawTicks: false
                    },
                    ticks: {
                        color: textColor,
                        maxTicksLimit: 8,
                        callback: function(value, index) {
                            const date = new Date(this.getLabelForValue(value));
                            const now = new Date();
                            const diffHours = (now - date) / (1000 * 60 * 60);
                            
                            if (diffHours < 24) {
                                return date.toLocaleTimeString('en-US', { 
                                    hour: '2-digit', 
                                    minute: '2-digit' 
                                });
                            } else {
                                return date.toLocaleDateString('en-US', { 
                                    month: 'short', 
                                    day: 'numeric' 
                                });
                            }
                        }
                    }
                },
                y: {
                    display: true,
                    position: 'right',
                    grid: {
                        color: gridColor,
                        drawOnChartArea: true,
                        drawTicks: false
                    },
                    ticks: {
                        color: textColor,
                        maxTicksLimit: 8,
                        callback: function(value) {
                            return Utils.formatCurrency(value, 'USD', value > 1 ? 2 : 6);
                        }
                    }
                }
            },
            elements: {
                point: {
                    radius: 0,
                    hoverRadius: 6,
                    hitRadius: 10
                },
                line: {
                    borderWidth: 2,
                    tension: 0.1
                }
            }
        };
    }

    // Create or update a line chart
    async createLineChart(canvasId, symbol, period = '24h') {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.error(`Canvas with id '${canvasId}' not found`);
            return null;
        }

        const ctx = canvas.getContext('2d');
        
        try {
            // Get historical data
            const historicalData = await cryptoAPI.getHistoricalData(symbol, period);
            
            if (!historicalData || historicalData.length === 0) {
                throw new Error('No data available for chart');
            }

            // Prepare chart data
            const labels = historicalData.map(item => item.time);
            const prices = historicalData.map(item => item.close);
            
            // Determine if price is going up or down for color
            const firstPrice = prices[0];
            const lastPrice = prices[prices.length - 1];
            const isPositive = lastPrice >= firstPrice;
            
            const gradientFill = ctx.createLinearGradient(0, 0, 0, canvas.height);
            gradientFill.addColorStop(0, isPositive ? 
                'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)'
            );
            gradientFill.addColorStop(1, 'rgba(0, 0, 0, 0)');

            const chartData = {
                labels: labels,
                datasets: [{
                    label: `${symbol} Price`,
                    data: prices,
                    borderColor: isPositive ? this.chartColors.success : this.chartColors.error,
                    backgroundColor: gradientFill,
                    fill: true,
                    tension: 0.1
                }]
            };

            // Destroy existing chart if it exists
            if (this.charts[canvasId]) {
                this.charts[canvasId].destroy();
            }

            // Create new chart
            this.charts[canvasId] = new Chart(ctx, {
                type: 'line',
                data: chartData,
                options: { 
                    ...this.defaultOptions,
                    plugins: {
                        ...this.defaultOptions.plugins,
                        tooltip: {
                            ...this.defaultOptions.plugins.tooltip,
                            callbacks: {
                                title: function(context) {
                                    const date = new Date(context[0].label);
                                    return date.toLocaleString();
                                },
                                label: function(context) {
                                    return `${symbol}: ${Utils.formatCurrency(context.parsed.y)}`;
                                }
                            }
                        }
                    }
                }
            });

            return this.charts[canvasId];
        } catch (error) {
            console.error(`Error creating chart for ${symbol}:`, error);
            this.showChartError(canvas, `Unable to load ${symbol} chart`);
            return null;
        }
    }

    // Create OHLC (candlestick) chart
    async createOHLCChart(canvasId, symbol, period = '24h') {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.error(`Canvas with id '${canvasId}' not found`);
            return null;
        }

        const ctx = canvas.getContext('2d');
        
        try {
            const historicalData = await cryptoAPI.getHistoricalData(symbol, period);
            
            if (!historicalData || historicalData.length === 0) {
                throw new Error('No OHLC data available');
            }

            // Prepare OHLC data
            const ohlcData = historicalData.map(item => ({
                x: item.time,
                o: item.open,
                h: item.high,
                l: item.low,
                c: item.close
            }));

            const chartData = {
                datasets: [{
                    label: `${symbol} OHLC`,
                    data: ohlcData,
                    borderColor: this.chartColors.primary,
                    backgroundColor: this.chartColors.primary
                }]
            };

            // Destroy existing chart
            if (this.charts[canvasId]) {
                this.charts[canvasId].destroy();
            }

            // Note: This would require a candlestick chart plugin
            // For now, we'll fall back to line chart
            return this.createLineChart(canvasId, symbol, period);
            
        } catch (error) {
            console.error(`Error creating OHLC chart for ${symbol}:`, error);
            this.showChartError(canvas, `Unable to load ${symbol} OHLC chart`);
            return null;
        }
    }

    // Create mini chart for crypto cards
    createMiniChart(canvasId, data, isPositive = true) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return null;

        const ctx = canvas.getContext('2d');
        
        const chartData = {
            labels: data.map((_, index) => index),
            datasets: [{
                data: data,
                borderColor: isPositive ? this.chartColors.success : this.chartColors.error,
                backgroundColor: isPositive ? 
                    'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)',
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 0,
                borderWidth: 1.5
            }]
        };

        // Destroy existing chart
        if (this.charts[canvasId]) {
            this.charts[canvasId].destroy();
        }

        this.charts[canvasId] = new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: false }
                },
                scales: {
                    x: { display: false },
                    y: { display: false }
                },
                elements: {
                    point: { radius: 0 },
                    line: { tension: 0.4 }
                }
            }
        });

        return this.charts[canvasId];
    }

    // Create prediction chart
    createPredictionChart(canvasId, historicalData, predictionData) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return null;

        const ctx = canvas.getContext('2d');
        
        // Combine historical and prediction data
        const allData = [
            ...historicalData.map(item => ({
                x: item.time,
                y: item.close,
                type: 'historical'
            })),
            ...predictionData.map(item => ({
                x: item.time,
                y: item.predicted,
                type: 'prediction'
            }))
        ];

        const chartData = {
            datasets: [
                {
                    label: 'Historical Price',
                    data: historicalData.map(item => ({ x: item.time, y: item.close })),
                    borderColor: this.chartColors.primary,
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    fill: false
                },
                {
                    label: 'Predicted Price',
                    data: predictionData.map(item => ({ x: item.time, y: item.predicted })),
                    borderColor: this.chartColors.warning,
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    borderDash: [5, 5],
                    fill: false
                }
            ]
        };

        // Destroy existing chart
        if (this.charts[canvasId]) {
            this.charts[canvasId].destroy();
        }

        this.charts[canvasId] = new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                ...this.defaultOptions,
                plugins: {
                    ...this.defaultOptions.plugins,
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        ...this.defaultOptions.plugins.tooltip,
                        callbacks: {
                            title: function(context) {
                                const date = new Date(context[0].parsed.x);
                                return date.toLocaleString();
                            },
                            label: function(context) {
                                const type = context.datasetIndex === 0 ? 'Historical' : 'Predicted';
                                return `${type}: ${Utils.formatCurrency(context.parsed.y)}`;
                            }
                        }
                    }
                }
            }
        });

        return this.charts[canvasId];
    }

    // Show error message on chart canvas
    showChartError(canvas, message) {
        const ctx = canvas.getContext('2d');
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = isDark ? '#374151' : '#f3f4f6';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = isDark ? '#9ca3af' : '#6b7280';
        ctx.font = '14px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(message, canvas.width / 2, canvas.height / 2);
    }

    // Update chart colors when theme changes
    updateThemeColors() {
        Object.values(this.charts).forEach(chart => {
            if (chart && chart.options) {
                const newOptions = this.getDefaultChartOptions();
                chart.options = { ...chart.options, ...newOptions };
                chart.update();
            }
        });
    }

    // Destroy specific chart
    destroyChart(canvasId) {
        if (this.charts[canvasId]) {
            this.charts[canvasId].destroy();
            delete this.charts[canvasId];
        }
    }

    // Destroy all charts
    destroyAllCharts() {
        Object.keys(this.charts).forEach(canvasId => {
            this.destroyChart(canvasId);
        });
    }

    // Update chart period
    async updateChartPeriod(canvasId, symbol, period) {
        const chart = this.charts[canvasId];
        if (!chart) {
            return this.createLineChart(canvasId, symbol, period);
        }

        try {
            const historicalData = await cryptoAPI.getHistoricalData(symbol, period);
            
            if (!historicalData || historicalData.length === 0) {
                throw new Error('No data available');
            }

            const labels = historicalData.map(item => item.time);
            const prices = historicalData.map(item => item.close);
            
            chart.data.labels = labels;
            chart.data.datasets[0].data = prices;
            chart.update('none');
            
            return chart;
        } catch (error) {
            console.error(`Error updating chart period for ${symbol}:`, error);
            return null;
        }
    }
}

// Initialize chart manager
const chartManager = new ChartManager();

// Export for global use
window.ChartManager = ChartManager;
window.chartManager = chartManager;