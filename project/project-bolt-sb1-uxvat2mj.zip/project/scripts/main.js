// Main Application Controller
class CryptoTrackerApp {
    constructor() {
        this.initialized = false;
        this.updateInterval = null;
        this.searchTimeout = null;
        this.init();
    }

    async init() {
        if (this.initialized) return;
        
        try {
            console.log('🚀 Initializing CryptoTracker Pro...');
            
            // Initialize core systems
            ThemeManager.init();
            
            // Set up event handlers
            this.setupEventHandlers();
            
            // Start real-time updates
            this.startRealTimeUpdates();
            
            // Initialize search functionality
            this.initializeSearch();
            
            this.initialized = true;
            console.log('✅ CryptoTracker Pro initialized successfully');
            
        } catch (error) {
            console.error('❌ Failed to initialize CryptoTracker Pro:', error);
        }
    }

    setupEventHandlers() {
        // Refresh data button
        const refreshBtn = document.getElementById('refreshData');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshAllData());
        }

        // Sort/filter controls
        const sortSelect = document.getElementById('sortBy');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => this.handleSortChange(e.target.value));
        }

        // Featured chart timeframe controls
        this.setupFeaturedChartControls();

        // Theme change handler
        document.addEventListener('themeChanged', () => {
            chartManager.updateThemeColors();
        });

        // Window resize handler for responsive charts
        window.addEventListener('resize', Utils.debounce(() => {
            Object.values(chartManager.charts).forEach(chart => {
                if (chart && chart.resize) {
                    chart.resize();
                }
            });
        }, 250));

        // Page visibility change handler
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.pauseRealTimeUpdates();
            } else {
                this.resumeRealTimeUpdates();
            }
        });
    }

    setupFeaturedChartControls() {
        const chartControls = document.querySelectorAll('#homePage .chart-btn');
        chartControls.forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                
                // Update active button
                chartControls.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                const timeframe = btn.dataset.timeframe || '24h';
                await chartManager.updateChartPeriod('featuredChart', 'BTC', timeframe);
            });
        });
    }

    initializeSearch() {
        const searchInput = document.getElementById('searchInput');
        if (!searchInput) return;

        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            
            // Clear previous timeout
            if (this.searchTimeout) {
                clearTimeout(this.searchTimeout);
            }
            
            // Debounced search
            this.searchTimeout = setTimeout(async () => {
                if (query.length >= 2) {
                    await this.performSearch(query);
                } else {
                    this.clearSearchResults();
                }
            }, CONFIG.UI.DEBOUNCE_DELAY);
        });

        // Handle search result selection
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const query = e.target.value.trim().toUpperCase();
                if (Utils.isValidCryptoSymbol(query)) {
                    navigationManager.navigateToCoin(query);
                    searchInput.value = '';
                }
            }
        });
    }

    async performSearch(query) {
        try {
            const results = await cryptoAPI.searchCryptos(query);
            this.displaySearchResults(results);
        } catch (error) {
            console.error('Search failed:', error);
        }
    }

    displaySearchResults(results) {
        // Create search results dropdown
        let dropdown = document.getElementById('searchDropdown');
        if (!dropdown) {
            dropdown = document.createElement('div');
            dropdown.id = 'searchDropdown';
            dropdown.className = 'search-dropdown';
            document.querySelector('.search-container').appendChild(dropdown);
        }

        if (results.length === 0) {
            dropdown.innerHTML = '<div class="search-no-results">No results found</div>';
        } else {
            dropdown.innerHTML = results.map(crypto => `
                <div class="search-result-item" data-symbol="${crypto.symbol}">
                    <img src="${crypto.imageUrl}" alt="${crypto.name}" class="search-result-logo">
                    <div class="search-result-info">
                        <div class="search-result-name">${crypto.name}</div>
                        <div class="search-result-symbol">${crypto.symbol}</div>
                    </div>
                    <div class="search-result-price">${crypto.priceDisplay}</div>
                </div>
            `).join('');

            // Add click handlers to search results
            dropdown.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', () => {
                    const symbol = item.dataset.symbol;
                    navigationManager.navigateToCoin(symbol);
                    this.clearSearchResults();
                    document.getElementById('searchInput').value = '';
                });
            });
        }

        dropdown.style.display = 'block';
        
        // Hide dropdown when clicking outside
        setTimeout(() => {
            const hideDropdown = (e) => {
                if (!e.target.closest('.search-container')) {
                    this.clearSearchResults();
                    document.removeEventListener('click', hideDropdown);
                }
            };
            document.addEventListener('click', hideDropdown);
        }, 100);
    }

    clearSearchResults() {
        const dropdown = document.getElementById('searchDropdown');
        if (dropdown) {
            dropdown.style.display = 'none';
            dropdown.innerHTML = '';
        }
    }

    startRealTimeUpdates() {
        // Initial load
        this.updateRealTimeData();
        
        // Set up periodic updates
        this.updateInterval = setInterval(() => {
            this.updateRealTimeData();
        }, CONFIG.CRYPTO.REFRESH_INTERVAL);
    }

    pauseRealTimeUpdates() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }
    }

    resumeRealTimeUpdates() {
        if (!this.updateInterval) {
            this.startRealTimeUpdates();
        }
    }

    async updateRealTimeData() {
        try {
            // Only update if on home page to save API calls
            if (navigationManager.currentPage === 'home') {
                // Update market overview
                const overview = await cryptoAPI.getMarketOverview();
                if (overview) {
                    navigationManager.updateMarketOverview(overview);
                }

                // Update crypto prices in the grid
                await this.updateCryptoPrices();
            }
            
            // Update current coin page if viewing specific coin
            if (navigationManager.currentPage === 'coin' && navigationManager.currentCoin) {
                await this.updateCurrentCoinData();
            }

        } catch (error) {
            console.error('Real-time update failed:', error);
        }
    }

    async updateCryptoPrices() {
        const cryptoCards = document.querySelectorAll('.crypto-card');
        const symbols = Array.from(cryptoCards).map(card => card.dataset.symbol).filter(Boolean);
        
        if (symbols.length === 0) return;

        try {
            // Get updated prices for visible cryptos
            const prices = await cryptoAPI.getMultiplePrices(symbols);
            
            cryptoCards.forEach(card => {
                const symbol = card.dataset.symbol;
                const newPrice = prices[symbol];
                
                if (newPrice) {
                    const priceElement = card.querySelector('.crypto-price');
                    const changeElement = card.querySelector('.crypto-change');
                    
                    if (priceElement) {
                        // Add price change animation
                        priceElement.classList.add('price-update');
                        priceElement.textContent = Utils.formatCurrency(newPrice);
                        
                        setTimeout(() => {
                            priceElement.classList.remove('price-update');
                        }, 1000);
                    }
                }
            });
            
        } catch (error) {
            console.error('Failed to update crypto prices:', error);
        }
    }

    async updateCurrentCoinData() {
        if (!navigationManager.currentCoin) return;

        try {
            const coinData = await cryptoAPI.getCryptoData(navigationManager.currentCoin);
            navigationManager.updateCoinHeader(coinData);
            navigationManager.updateCoinStats(coinData);
        } catch (error) {
            console.error('Failed to update coin data:', error);
        }
    }

    async refreshAllData() {
        const refreshBtn = document.getElementById('refreshData');
        if (refreshBtn) {
            refreshBtn.disabled = true;
            refreshBtn.innerHTML = '<i class="fas fa-sync-alt fa-spin"></i> Refreshing...';
        }

        try {
            // Clear cache to force fresh data
            CacheManager.clear();
            
            // Reload current page data
            await navigationManager.triggerPageLoad(navigationManager.currentPage);
            
            // Success feedback
            if (refreshBtn) {
                refreshBtn.innerHTML = '<i class="fas fa-check"></i> Updated';
                setTimeout(() => {
                    refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
                    refreshBtn.disabled = false;
                }, 2000);
            }
            
        } catch (error) {
            console.error('Refresh failed:', error);
            if (refreshBtn) {
                refreshBtn.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error';
                setTimeout(() => {
                    refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
                    refreshBtn.disabled = false;
                }, 2000);
            }
        }
    }

    async handleSortChange(sortBy) {
        const cryptoGrid = document.getElementById('cryptoGrid');
        if (!cryptoGrid) return;

        try {
            // Show loading state
            cryptoGrid.style.opacity = '0.5';
            
            // Get fresh data with new sorting
            const topCryptos = await cryptoAPI.getTopCryptos(20);
            
            // Sort the data
            const sortedCryptos = this.sortCryptos(topCryptos, sortBy);
            
            // Update display
            navigationManager.displayCryptoGrid(sortedCryptos);
            
            // Restore opacity
            cryptoGrid.style.opacity = '1';
            
        } catch (error) {
            console.error('Sort failed:', error);
            cryptoGrid.style.opacity = '1';
        }
    }

    sortCryptos(cryptos, sortBy) {
        const sortedCryptos = [...cryptos];
        
        switch (sortBy) {
            case 'price':
                return sortedCryptos.sort((a, b) => b.price - a.price);
            case 'change_24h':
                return sortedCryptos.sort((a, b) => b.change24h - a.change24h);
            case 'volume':
                return sortedCryptos.sort((a, b) => b.volume24h - a.volume24h);
            case 'market_cap':
            default:
                return sortedCryptos.sort((a, b) => b.marketCap - a.marketCap);
        }
    }

    // Public methods for external access
    getCurrentPage() {
        return navigationManager.currentPage;
    }

    getCurrentCoin() {
        return navigationManager.currentCoin;
    }

    // Cleanup method
    destroy() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        chartManager.destroyAllCharts();
        CacheManager.clear();
        predictionSystem.clearCache();
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add loading CSS
    const style = document.createElement('style');
    style.textContent = `
        .price-update {
            animation: priceFlash 1s ease;
        }
        
        @keyframes priceFlash {
            0% { background-color: rgba(34, 197, 94, 0.3); }
            100% { background-color: transparent; }
        }
        
        .search-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            box-shadow: 0 4px 6px var(--shadow-color);
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }
        
        .search-result-item {
            display: flex;
            align-items: center;
            padding: var(--spacing-3);
            cursor: pointer;
            transition: background-color var(--transition-fast);
        }
        
        .search-result-item:hover {
            background: var(--bg-secondary);
        }
        
        .search-result-logo {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            margin-right: var(--spacing-3);
        }
        
        .search-result-info {
            flex: 1;
        }
        
        .search-result-name {
            font-weight: 500;
            font-size: var(--font-size-sm);
        }
        
        .search-result-symbol {
            color: var(--text-secondary);
            font-size: var(--font-size-xs);
        }
        
        .search-result-price {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .search-no-results {
            padding: var(--spacing-4);
            text-align: center;
            color: var(--text-secondary);
            font-size: var(--font-size-sm);
        }
        
        .crypto-prediction-badge {
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            color: white;
            padding: var(--spacing-1) var(--spacing-2);
            border-radius: var(--border-radius-sm);
            font-size: var(--font-size-xs);
            text-align: center;
            margin-top: var(--spacing-2);
        }
    `;
    document.head.appendChild(style);
    
    // Initialize the app
    window.app = new CryptoTrackerApp();
});

// Export for global use
window.CryptoTrackerApp = CryptoTrackerApp;